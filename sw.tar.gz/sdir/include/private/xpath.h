#ifndef XML_XPATH_H_PRIVATE__
#define XML_XPATH_H_PRIVATE__

XML_HIDDEN void
xmlInitXPathInternal(void);

#endif /* XML_XPATH_H_PRIVATE__ */
